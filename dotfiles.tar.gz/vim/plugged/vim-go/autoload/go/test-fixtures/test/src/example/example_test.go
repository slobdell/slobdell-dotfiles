package main

import (
	"fmt"
)

func ExampleHelloWorld() {
	fmt.Println("Hello, World")
	// Output: What's shakin
}
