// +build constrained

package config

// foo is constrained and this comment exists to make the line numbers different than foo.go
func foo() {
	println("foo")
}
